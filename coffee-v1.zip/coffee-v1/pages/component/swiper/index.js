// pages/goods/swiper/index.js
Component({
  options:{
    styleIsolation: 'apply-shared'
  },
  properties:{
    swiperImg:{
      type: Array
    },
	height:{
		type:String,
		default:'750rpx'
	}
  },
  data: {

  },
})