// pages/coffeeShopping/page/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
	  list:[
		  {
			  'name':'好品',
			  "url":'/pages/coffeeShopping/page/shoplist/index',
		  }, {
			  'name':'活动',
			  "url":'/pages/coffeeShopping/page/activity/index/index',
		  }, {
			  'name':'课程',
			  "url":'/pages/coffeeShopping/page/course/course',
		  }, {
			  'name':'优惠券',
			  "url":'/pages/coffeeShopping/page/coupon/coupon',
		  }
	  ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})