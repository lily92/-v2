module.exports = {
  AppID:        'wxb1c130435e738d6e',
  AppSecret:    '01a52002372d9190ce3b2f88455199081',
  SN:           '1',
  API_URL:      'https://wx.shushuhui.com/',
  ACCESS:       'kedieonlinetest2017*',
  IMGURL:       'https://wx.shushuhui.com',
}
