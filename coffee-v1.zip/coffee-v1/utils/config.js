const config = {
  api_blink_url: 'https://jikelianmeng.tanghan.cn/api/app/',
  api_images_url: 'https://jikelianmeng.tanghan.cn/',
}

export { config }